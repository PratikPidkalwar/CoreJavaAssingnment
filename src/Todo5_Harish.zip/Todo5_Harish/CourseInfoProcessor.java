package Todo5_Harish;

public interface CourseInfoProcessor {
	float processCourseInfo(Course[] CArr,CourseInfo cf);
}
